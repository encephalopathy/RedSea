Install the game by double clicking on "setup.exe"

Keyboard Controls:
Left Arrow -- Moves Left.
Right Arrow -- Moves Right.
Up Arrow -- Moves Up.
Down Arrow -- Moves Down. 